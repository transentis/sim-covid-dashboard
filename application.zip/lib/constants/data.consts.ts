export const X = 'x';
export const Y = 'y';

export const MIN = 'min';
export const MAX = 'max';

export const LINE = 'line';
export const AREA = 'area';
