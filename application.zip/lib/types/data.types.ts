export type x = 'x';
export type y = 'y';
export type axes = x | y;

export type min = 'min';
export type max = 'max';
export type min_or_max = min | max;

export type line = 'line';
export type area = 'area';
export type lineOrArea = line | area;
